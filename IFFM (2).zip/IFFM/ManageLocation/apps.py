from django.apps import AppConfig


class ManagelocationConfig(AppConfig):
    name = 'ManageLocation'
