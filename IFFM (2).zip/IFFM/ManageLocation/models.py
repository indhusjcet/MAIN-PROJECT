from django.db import models


class District(models.Model):
    district_name = models.CharField(max_length=200)
