from django.contrib import admin
from.models import District

admin.site.site_header = 'Interactive Farmers forum'
admin.site.register(District)


