from django.apps import AppConfig


class InteractiveConfig(AppConfig):
    name = 'interactive'
