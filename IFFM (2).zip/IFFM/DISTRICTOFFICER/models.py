from django.db import models


class Districtofficer(models.Model):
    dof_fname =  models.CharField(max_length=100)
    dof_mname = models.CharField(max_length=100)
    dof_lname = models.CharField(max_length=100)
    dof_username = models.CharField(max_length=100)
    dof_password = models.CharField(max_length=100)
    dof_contact = models.IntegerField(max_length=100)
    dof_email = models.EmailField(max_length=100)






