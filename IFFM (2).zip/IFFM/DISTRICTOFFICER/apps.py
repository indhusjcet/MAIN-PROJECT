from django.apps import AppConfig


class DistrictofficerConfig(AppConfig):
    name = 'DISTRICTOFFICER'
