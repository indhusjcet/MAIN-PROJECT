from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
#from .models import *


class UserRegisterForm(UserCreationForm):
    Email = forms.EmailField()
    Firstname = forms.CharField()
    Middlename= forms.CharField()
    Lastname = forms.CharField()
    #gender = forms.RadioSelect()
    Housename = forms.CharField()
    Phone = forms.CharField()





    class Meta:
        model = User
        fields = ['Firstname', 'Middlename', 'Lastname', 'Housename', 'Phone', 'Email', 'username', 'password1', 'password2']

